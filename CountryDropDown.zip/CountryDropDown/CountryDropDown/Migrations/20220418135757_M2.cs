﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CountryDropDown.Migrations
{
    public partial class M2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            

            migrationBuilder.CreateTable(
                name: "ListTb",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CountryID = table.Column<int>(type: "int", nullable: false),
                    StateID = table.Column<int>(type: "int", nullable: false),
                    CityID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ListTb", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ListTb_CityTb_CityID",
                        column: x => x.CityID,
                        principalTable: "CityTb",
                        principalColumn: "CityID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ListTb_CountryTb_CountryID",
                        column: x => x.CountryID,
                        principalTable: "CountryTb",
                        principalColumn: "CountryID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ListTb_StateTb_StateID",
                        column: x => x.StateID,
                        principalTable: "StateTb",
                        principalColumn: "StateID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ListTb_StateID",
                table: "ListTb",
                column: "StateID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ListTb");

            migrationBuilder.DropTable(
                name: "CityTb");

            migrationBuilder.DropTable(
                name: "CountryTb");

            migrationBuilder.DropTable(
                name: "StateTb");
        }
    }
}
