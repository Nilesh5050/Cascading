﻿using CountryDropDown.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CountryDropDown.Controllers
{
    public class DropDownController : Controller
    {
        private ApplicationDbContext _dbContext;

        public DropDownController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult Create()
        {

            List<Country> countrylist = new List<Country>();

            countrylist = (from country in _dbContext.CountryTb select country).ToList();


            countrylist.Insert(0, new Country { CountryID = 0, CountryName = "Select" });


            ViewBag.ListofCountry = countrylist;
            return View();
        }
        

        [HttpPost]
        public IActionResult Create(ListData model)
        {
            _dbContext.Add(model);
            _dbContext.SaveChanges();
            return RedirectToAction("List");
        }


        public IActionResult Edit(int id)
        {
            ListData listdata = new ListData();

            ListData list = _dbContext.ListTb.Find(id);

            List<Country> countrylist = new List<Country>();

            countrylist = (from country in _dbContext.CountryTb select country).ToList();


            countrylist.Insert(0, new Country { CountryID = 0, CountryName = "Select" });

            //-------------------------------------------------------------------------//


            //List<State> statelist = new List<State>();

            //statelist = (from state in _dbContext.StateTb select state).ToList();




            //statelist.Insert(0, new State { StateID = 0, StateName = "Select" });

            List<State> statelist = new List<State>();
            statelist = (from state in _dbContext.StateTb
                         where state.CountryID == list.CountryID
                         select state).ToList();

            statelist.Insert(0, new State { StateID = 0, StateName = "Select" });

            //---------------------------------------------------------------------------//

            //List<City> citylist = new List<City>();

            //citylist = (from city in _dbContext.CityTb select city).ToList();


            //citylist.Insert(0, new City { CityID = 0, CityName = "Select" });

            List<City> citylist = new List<City>();

            citylist = (from city in _dbContext.CityTb
                        where city.StateID == list.StateID && city.CountryID == list.CountryID
                        select city).ToList();

            citylist.Insert(0, new City { CityID = 0, CityName = "Select" });


            ViewBag.ListofCountry = countrylist;
            ViewBag.ListofState = statelist;
            ViewBag.ListofCity = citylist;
            return View(list);
        }






        public IActionResult List()
        {
            List<ListData> listDatas = _dbContext.ListTb
                .Include(c => c.Country)
                .Include(cy => cy.State)
                .Include(cy => cy.City)
                .ToList();
            return View(listDatas);
        }
        public JsonResult GetState(int CountryID)
        {
            List<State> statelist = new List<State>();
            statelist = (from state in _dbContext.StateTb
                         where state.CountryID == CountryID
                         select state).ToList();

            statelist.Insert(0, new State { StateID = 0, StateName = "Select" });
            return Json(statelist);
            //return Json(new SelectList(statelist, "StateID", "StateName"));
        }
        public JsonResult GetCity(int StateID,int CountryID)
        {
            List<City> citylist = new List<City>();

            citylist = (from city in _dbContext.CityTb
                         where city.StateID == StateID && city.CountryID==CountryID
                         select city).ToList();

            citylist.Insert(0, new City { CityID = 0, CityName = "Select" });
            return Json(citylist);
        }
    }
}
